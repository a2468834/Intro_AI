g++ PR1.cpp -o PR1 -std=c++11
./PR1 < IntroAI_PR1_test.txt
