#include <iostream>

using namespace std;

int main()
{
	int itr = 0;
	cout<<itr<<endl;
	while(true)
	{
		itr++;
		if(itr == 5)break;
	}
	cout<<itr<<endl;
	
	return 0;
}